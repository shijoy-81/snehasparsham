"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { X, MessageCircle, Send, Phone, Heart, Users } from "lucide-react"

interface Message {
  id: number
  text: string
  isBot: boolean
  timestamp: Date
}

interface QuickQuestion {
  id: string
  text: string
  response: string
}

const quickQuestions: QuickQuestion[] = [
  {
    id: "pricing",
    text: "What are your pricing plans?",
    response:
      "We offer 3 subscription plans: Basic (₹2,499/month), Standard (₹5,999/month), and Premium (₹9,999/month). We also have one-time services starting from ₹200. Would you like details about any specific plan?",
  },
  {
    id: "services",
    text: "What services do you provide?",
    response:
      "We provide comprehensive eldercare services including: Driver service, Hospital visits, Grocery delivery, Government helpdesk, Maid service, Nurse visits, Medicine delivery, Bank visits, and ChitChat companionship. Each family gets a dedicated Relationship Manager.",
  },
  {
    id: "emergency",
    text: "Do you have emergency support?",
    response:
      "Yes! We provide 24/7 emergency support and offer an Emergency Alert System setup (₹2,999) with wearable panic button, instant family notifications, and local emergency response team.",
  },
  {
    id: "areas",
    text: "Which areas do you cover?",
    response:
      "We serve urban and semi-urban areas across Kerala, focusing on independent homes. Our relationship managers cover different regions to ensure local support for your parents.",
  },
  {
    id: "contact",
    text: "How can I contact you?",
    response:
      "You can reach our relationship managers: Lipin Paul (+91 9947005681), Albin Paul (+91 9048191613), or Jojo Joseph (+91 9633704621). You can also email us or schedule a free consultation.",
  },
  {
    id: "trial",
    text: "Do you offer a free trial?",
    response:
      "Yes! We offer a free trial for new customers. You can start with our services and experience the quality of care before committing to a subscription plan.",
  },
]

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm here to help you learn about SnehaSparsham's eldercare services. How can I assist you today?",
      isBot: true,
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")

  const addMessage = (text: string, isBot = false) => {
    const newMessage: Message = {
      id: messages.length + 1,
      text,
      isBot,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, newMessage])
  }

  const handleQuickQuestion = (question: QuickQuestion) => {
    addMessage(question.text, false)
    setTimeout(() => {
      addMessage(question.response, true)
    }, 500)
  }

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      addMessage(inputValue, false)
      setInputValue("")

      // Simple response logic
      setTimeout(() => {
        addMessage(
          "Thank you for your message! For detailed assistance, please contact our relationship managers or schedule a free consultation. Our team will get back to you shortly.",
          true,
        )
      }, 500)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  return (
    <>
      {/* Chatbot Toggle Button */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-50">
          <Button
            onClick={() => setIsOpen(true)}
            className="bg-green-600 hover:bg-green-700 rounded-full w-14 h-14 shadow-lg"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        </div>
      )}

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-80 h-96">
          <Card className="h-full flex flex-col shadow-xl">
            <CardHeader className="bg-green-600 text-white rounded-t-lg flex flex-row items-center justify-between py-3">
              <div className="flex items-center gap-2">
                <Heart className="h-5 w-5" />
                <div>
                  <CardTitle className="text-sm">SnehaSparsham Support</CardTitle>
                  <p className="text-xs text-green-100">We're here to help!</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-green-700 h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>

            <CardContent className="flex-1 flex flex-col p-0">
              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.isBot ? "justify-start" : "justify-end"}`}>
                    <div
                      className={`max-w-[80%] p-2 rounded-lg text-sm ${
                        message.isBot ? "bg-gray-100 text-gray-800" : "bg-green-600 text-white"
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Questions */}
              {messages.length <= 2 && (
                <div className="p-4 border-t bg-gray-50">
                  <p className="text-xs text-gray-600 mb-2">Quick questions:</p>
                  <div className="space-y-1">
                    {quickQuestions.slice(0, 3).map((question) => (
                      <Button
                        key={question.id}
                        variant="outline"
                        size="sm"
                        className="w-full text-left justify-start text-xs h-8"
                        onClick={() => handleQuickQuestion(question)}
                      >
                        {question.text}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Area */}
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    className="text-sm"
                  />
                  <Button onClick={handleSendMessage} size="sm" className="bg-green-600 hover:bg-green-700">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>

                {/* Contact Options */}
                <div className="flex gap-2 mt-2">
                  <Button variant="outline" size="sm" className="text-xs flex-1">
                    <Phone className="h-3 w-3 mr-1" />
                    Call Now
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs flex-1">
                    <Users className="h-3 w-3 mr-1" />
                    Free Consultation
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}
