"use client"

import {
  ArrowRight,
  Check,
  Heart,
  Phone,
  Shield,
  Star,
  Users,
  Bell,
  FileText,
  ShieldCheck,
  MessageCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import Chatbot from "@/components/chatbot"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Chatbot Component */}
      <Chatbot />

      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="h-8 w-8 text-green-600" />
            <span className="text-xl font-bold text-gray-900">SnehaSparsham</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#services" className="text-gray-600 hover:text-green-600">
              Services
            </a>
            <a href="#pricing" className="text-gray-600 hover:text-green-600">
              Pricing
            </a>
            <a href="#how-it-works" className="text-gray-600 hover:text-green-600">
              How It Works
            </a>
            <a href="#contact" className="text-gray-600 hover:text-green-600">
              Contact
            </a>
          </nav>
          <Button className="bg-green-600 hover:bg-green-700">
            <Phone className="h-4 w-4 mr-2" />
            Call Now
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-100">Trusted by 2,500+ NRI families</Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Peace of Mind for Your
            <span className="text-green-600 block">Beloved Parents</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Professional eldercare support services in Kerala for NRI families. From daily chores to medical visits,
            we're your parents' trusted companions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              Start Free Trial
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline">
              Watch Demo
            </Button>
          </div>
          <div className="mt-12 flex items-center justify-center gap-8 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Background Verified Staff
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              24/7 Emergency Support
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Dedicated Relationship Manager
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Comprehensive Care Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything your parents need, delivered with care and professionalism
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {[
              {
                icon: "🚗",
                title: "Driver Service",
                description: "Safe transportation with or without car for all needs",
              },
              {
                icon: "🏥",
                title: "Hospital Visits",
                description: "Accompaniment to medical appointments and procedures",
              },
              {
                icon: "🛒",
                title: "Grocery Delivery",
                description: "Daily or weekly curated provisioning and essentials",
              },
              {
                icon: "🏛️",
                title: "Govt Helpdesk",
                description: "Paperwork assistance, pension, Aadhaar, and taxes",
              },
              {
                icon: "🧹",
                title: "Maid Service",
                description: "House cleaning and laundry by verified professionals",
              },
              {
                icon: "🩺",
                title: "Nurse Visits",
                description: "Home nursing, health checks, and post-op care",
              },
              {
                icon: "💊",
                title: "Medicine Delivery",
                description: "Prescription pickup and delivery from pharmacies",
              },
              {
                icon: "📞",
                title: "Relationship Manager",
                description: "Your dedicated point of contact for all needs",
              },
              {
                icon: "🏦",
                title: "Bank Visit",
                description: "Any bank related activities and assistance",
              },
              {
                icon: "💬",
                title: "ChitChat",
                description: "Spend quality time with your elders sharing local gossips",
              },
            ].map((service, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl mb-2">{service.icon}</div>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What You Will Get Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What You Will Get</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our commitment to exceptional care and peace of mind for your family
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className="bg-green-50 rounded-lg p-8 flex flex-col items-center md:items-start text-center md:text-left">
              <div className="bg-green-100 p-4 rounded-full mb-6">
                <Users className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Dedicated Relationship Manager</h3>
              <p className="text-gray-600">
                Each family is assigned a dedicated Relationship Manager who becomes your single point of contact,
                understands your parents' unique needs, and ensures consistent quality care.
              </p>
            </div>

            <div className="bg-green-50 rounded-lg p-8 flex flex-col items-center md:items-start text-center md:text-left">
              <div className="bg-green-100 p-4 rounded-full mb-6">
                <FileText className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Monthly Reports & Calls</h3>
              <p className="text-gray-600">
                Receive detailed monthly PDF reports on your parents' wellbeing, service usage, and health metrics,
                complemented by scheduled calls with your Relationship Manager.
              </p>
            </div>

            <div className="bg-green-50 rounded-lg p-8 flex flex-col items-center md:items-start text-center md:text-left">
              <div className="bg-green-100 p-4 rounded-full mb-6">
                <Bell className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Emergency Alert System</h3>
              <p className="text-gray-600">
                Our emergency panic button app and optional wearable device ensure immediate assistance is always
                available, with alerts sent directly to our response team and family members.
              </p>
            </div>

            <div className="bg-green-50 rounded-lg p-8 flex flex-col items-center md:items-start text-center md:text-left">
              <div className="bg-green-100 p-4 rounded-full mb-6">
                <ShieldCheck className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Trust & Quality Assurance</h3>
              <p className="text-gray-600">
                All our staff undergo rigorous background verification and training. We conduct regular satisfaction
                surveys to ensure our services consistently exceed your expectations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Trusted Relationship Managers Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Trusted Relationship Managers</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Meet our dedicated team of relationship managers who will be your family's trusted companions
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                name: "Lipin Paul",
                email: "Plipin@snehasparshanam.com",
                phone: "+91 9947005681",
                role: "Senior Relationship Manager",
                photo: "/images/lipin.jpg",
              },
              {
                name: "Albin Paul",
                email: "palbin@snehasparshanam.com",
                phone: "+91 9048191613",
                role: "Relationship Manager",
                photo: "/images/albin.jpg",
              },
              {
                name: "Jojo Joseph",
                email: "Jjojo@snehasparshanam.com",
                phone: "+91 9633704621",
                role: "Relationship Manager",
                photo: "/images/jojo.jpg",
              },
              {
                name: "Robert Lobo",
                email: "Lrobo@snehasparshanam.com",
                phone: "+91 8861052575",
                role: "Relationship Manager",
                photo: "/images/robert.jpg",
              },
              {
                name: "Sabareesh Sadanandan",
                email: "ssabareesh@snehasparshanam.com",
                phone: "+91 7022640885",
                role: "Relationship Manager",
                photo: "/images/sabareesh.jpg",
              },
              {
                name: "Shijoy Varghese",
                email: "vshijoy@snehasparshanam.com",
                phone: "+91 8150035222",
                role: "Relationship Manager",
                photo: "/images/shijoy_new.jpg",
              },
            ].map((manager, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow bg-white">
                <CardHeader className="pb-4">
                  <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 border-4 border-green-100">
                    <img
                      src={manager.photo || "/placeholder.svg"}
                      alt={manager.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <CardTitle className="text-lg mb-2">{manager.name}</CardTitle>
                  <Badge variant="secondary" className="text-xs">
                    {manager.role}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-center gap-2 text-gray-600">
                      <Heart className="h-4 w-4" />
                      <span className="text-xs break-all">{manager.email}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2 text-gray-600">
                      <Phone className="h-4 w-4" />
                      <span className="text-sm">{manager.phone}</span>
                    </div>
                  </div>
                  <div className="flex gap-1 justify-center flex-wrap">
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs"
                      onClick={() => window.open(`tel:${manager.phone}`)}
                    >
                      <Phone className="h-3 w-3 mr-1" />
                      Call
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs"
                      onClick={() => window.open(`mailto:${manager.email}`)}
                    >
                      <Heart className="h-3 w-3 mr-1" />
                      Email
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs bg-green-50 hover:bg-green-100"
                      onClick={() =>
                        window.open(
                          `https://wa.me/${manager.phone.replace(/[^0-9]/g, "")}?text=Hello, I would like to know more about SnehaSparsham eldercare services.`,
                        )
                      }
                    >
                      <MessageCircle className="h-3 w-3 mr-1" />
                      Chat
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">
              Each family is assigned a dedicated relationship manager based on location and specific needs
            </p>
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              <Users className="mr-2 h-4 w-4" />
              Get Matched with Your RM
            </Button>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-gray-600">Choose the plan that best fits your family's needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Basic",
                price: "₹2,499",
                description: "Essential care for independent seniors",
                features: [
                  "Weekly check-ins",
                  "Dedicated Relationship Manager",
                  "2 hospital visits per month",
                  "Emergency support",
                  "Monthly wellness report",
                ],
                popular: false,
              },
              {
                name: "Standard",
                price: "₹5,999",
                description: "Comprehensive daily support",
                features: [
                  "Everything in Basic",
                  "Driver service 4x per month",
                  "Weekly grocery delivery",
                  "Maid service once per week",
                  "Medicine delivery",
                  "Government paperwork help",
                ],
                popular: true,
              },
              {
                name: "Premium",
                price: "₹9,999",
                description: "Complete care with medical support",
                features: [
                  "Everything in Standard",
                  "Nurse visits 2x per week",
                  "4 government errands per month",
                  "Daily check-ins",
                  "Priority emergency response",
                  "Health monitoring",
                ],
                popular: false,
              },
            ].map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? "border-green-500 shadow-lg scale-105" : ""}`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold text-green-600">{plan.price}</div>
                  <CardDescription className="text-sm">{plan.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" variant={plan.popular ? "default" : "outline"}>
                    Start Free Trial
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* One-Time Services Section */}
      <section className="py-20 px-4 bg-green-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">One-Time Services</h2>
            <p className="text-xl text-gray-600">Need occasional help? Book individual services as needed</p>
          </div>

          {/* Core Services */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto mb-12">
            {[
              {
                icon: "🚗",
                service: "Driver per Day",
                price: "₹600",
                description: "Full day driver service with or without vehicle",
                duration: "3 hours",
              },
              {
                icon: "🏥",
                service: "Hospital Visit",
                price: "₹750",
                description: "Accompaniment to medical appointments",
                duration: "3 hours",
              },
              {
                icon: "🧹",
                service: "Maid Service",
                price: "₹500",
                description: "House cleaning and basic maintenance",
                duration: "3 hours",
              },
              {
                icon: "🩺",
                service: "Nurse per Day",
                price: "₹1,200",
                description: "Professional nursing care at home",
                duration: "3 hours",
              },
              {
                icon: "💊",
                service: "Medicine Delivery",
                price: "₹200",
                description: "Prescription pickup and delivery",
                duration: "Within 10 KM radius",
              },
              {
                icon: "🏛️",
                service: "Government Errands",
                price: "₹1,000",
                description: "Paperwork, pension, Aadhaar assistance",
                duration: "Within 10 KM radius",
              },
            ].map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow bg-white">
                <CardHeader className="text-center pb-4">
                  <div className="text-4xl mb-3">{service.icon}</div>
                  <CardTitle className="text-lg mb-2">{service.service}</CardTitle>
                  <div className="text-2xl font-bold text-green-600">{service.price}</div>
                  <Badge variant="secondary" className="text-xs">
                    {service.duration}
                  </Badge>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                  <Button variant="outline" size="sm" className="w-full">
                    Book Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Special Occasion Services */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-center mb-8 text-gray-900">Special Occasion Services</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {[
                {
                  icon: "🎪",
                  service: "Arrange a Picnic",
                  price: "Custom Quote",
                  description: "One day event planning and coordination",
                },
                {
                  icon: "💐",
                  service: "Send Flowers",
                  price: "Custom Quote",
                  description: "Beautiful flower arrangements and delivery",
                },
                {
                  icon: "🎂",
                  service: "Celebrate Special Days",
                  price: "Custom Quote",
                  description: "Birthday, anniversary, and special day celebrations",
                },
                {
                  icon: "🎁",
                  service: "Plan a Surprise",
                  price: "Custom Quote",
                  description: "Thoughtful surprise planning and execution",
                },
                {
                  icon: "👥",
                  service: "Meet a Relative",
                  price: "Custom Quote",
                  description: "Facilitate family meetings and visits",
                },
                {
                  icon: "🕉️",
                  service: "Pilgrimage",
                  price: "Custom Quote",
                  description: "Religious and spiritual journey assistance",
                },
                {
                  icon: "🎉",
                  service: "Plan an Event",
                  price: "Custom Quote",
                  description: "Complete event planning and management",
                },
                {
                  icon: "💳",
                  service: "Pay Bills",
                  price: "Based on bill",
                  description: "Utility and service bill payment assistance",
                },
              ].map((service, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow bg-white">
                  <CardHeader className="text-center pb-4">
                    <div className="text-3xl mb-3">{service.icon}</div>
                    <CardTitle className="text-sm mb-2">{service.service}</CardTitle>
                    <div className="text-lg font-bold text-green-600">{service.price}</div>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-xs mb-4">{service.description}</p>
                    <Button variant="outline" size="sm" className="w-full text-xs">
                      Get Quote
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Emergency Alert Setup - Special Highlight */}
          <div className="mt-12 max-w-2xl mx-auto">
            <Card className="border-2 border-red-200 bg-red-50">
              <CardHeader className="text-center">
                <div className="text-4xl mb-3">🚨</div>
                <CardTitle className="text-xl text-red-800">Emergency Alert System Setup</CardTitle>
                <div className="text-3xl font-bold text-red-600">₹2,999</div>
                <Badge className="bg-red-100 text-red-800 hover:bg-red-100">One-time setup</Badge>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-700 mb-4">
                  Complete emergency response system with panic button, 24/7 monitoring, and instant family
                  notifications
                </p>
                <ul className="text-sm text-gray-600 mb-6 space-y-1">
                  <li>• Wearable panic button device</li>
                  <li>• 24/7 emergency monitoring</li>
                  <li>• Instant family notifications</li>
                  <li>• Local emergency response team</li>
                </ul>
                <Button className="bg-red-600 hover:bg-red-700 text-white">Setup Emergency System</Button>
              </CardContent>
            </Card>
          </div>

          {/* Custom Service */}
          <div className="mt-12 max-w-2xl mx-auto">
            <Card className="border-2 border-blue-200 bg-blue-50">
              <CardHeader className="text-center">
                <div className="text-4xl mb-3">✨</div>
                <CardTitle className="text-xl text-blue-800">Any Other Service</CardTitle>
                <div className="text-2xl font-bold text-blue-600">Custom Requirements</div>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-700 mb-4">
                  Have a unique requirement? We're here to help with any special needs or custom services for your
                  parents.
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">Define Your Requirements</Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Need a custom combination of services?</p>
            <Button size="lg" variant="outline">
              <Phone className="mr-2 h-4 w-4" />
              Speak to Our Care Coordinator
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Getting started is simple and takes just a few minutes</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "1",
                title: "Sign Up",
                description: "Create your account and tell us about your parents' needs",
              },
              {
                step: "2",
                title: "Get Matched",
                description: "We assign a dedicated Relationship Manager and local care team",
              },
              {
                step: "3",
                title: "Start Care",
                description: "Your parents begin receiving personalized care services",
              },
              {
                step: "4",
                title: "Stay Connected",
                description: "Receive regular updates and communicate through our app",
              },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Trusted by Families Worldwide</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Priya Nair",
                location: "Dubai, UAE",
                text: "Kerala ElderCare has been a blessing. My mother gets the care she needs, and I have peace of mind knowing she's in good hands.",
                rating: 5,
              },
              {
                name: "Rajesh Kumar",
                location: "London, UK",
                text: "The relationship manager calls me every month with updates. It's like having family taking care of my parents.",
                rating: 5,
              },
              {
                name: "Meera Thomas",
                location: "New York, USA",
                text: "When my father had his surgery, the team was there every step of the way. Exceptional service and care.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.text}"</p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.location}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-green-600 text-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
              <p className="text-xl mb-8 text-green-100">
                Join thousands of NRI families who trust us with their parents' care. Start with a free consultation
                today.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5" />
                  <span>Lipin Paul</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5" />
                  <span>+91 9947005681</span>
                </div>
                <div className="flex items-center gap-3">
                  <Heart className="h-5 w-5" />
                  <span>puallipin1988@gmail.com</span>
                </div>
              </div>
            </div>

            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle>Get Your Free Consultation</CardTitle>
                <CardDescription>Tell us about your parents' needs and we'll create a custom care plan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" placeholder="Your name" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" placeholder="Last name" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="your@email.com" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" placeholder="+971 50 123 4567" />
                </div>
                <div>
                  <Label htmlFor="location">Parent's Location in Kerala</Label>
                  <Input id="location" placeholder="City/District" />
                </div>
                <div>
                  <Label htmlFor="message">Tell us about your needs</Label>
                  <Textarea id="message" placeholder="What kind of support do your parents need?" />
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Schedule Free Consultation</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Heart className="h-6 w-6 text-green-500" />
                <span className="text-lg font-bold">SnehaSparsham</span>
              </div>
              <p className="text-gray-400">
                Bridging the gap between NRI children and their beloved parents in Kerala with a touch of love.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Driver Service</li>
                <li>Hospital Visits</li>
                <li>Grocery Delivery</li>
                <li>Nurse Visits</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>24/7 Emergency</li>
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-gray-400">
                <li>WhatsApp Support</li>
                <li>Facebook</li>
                <li>Instagram</li>
                <li>LinkedIn</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SnehaSparsham Elder Support Services. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
